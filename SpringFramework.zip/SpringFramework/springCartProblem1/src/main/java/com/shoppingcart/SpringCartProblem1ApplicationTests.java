package com.shoppingcart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCartProblem1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
