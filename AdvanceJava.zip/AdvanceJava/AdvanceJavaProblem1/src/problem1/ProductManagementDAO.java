package problem1;





public class ProductManagementDAO {
	
	public void getAllProducts() {
	}
	public product getProductById(String ID) {
		return null;
	}
	public  product addProduct(product product) {
		return null;
	}
	public  product deleteProduct(String ID) {
		return null;
	}
	public  product updateProduct(String ID, String name) {
		return null;
	}

}

