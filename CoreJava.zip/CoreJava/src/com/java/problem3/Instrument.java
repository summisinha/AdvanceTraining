package com.java.problem3;

abstract class Instrument {
	public abstract void play(); 
		
	 static class Piano extends Instrument{

		@Override
		public void play() {
			// TODO Auto-generated method stub
			System.out.println("Piano is playing tan tan tan tan");
		}
		
	}
	 
	static class Flute extends Instrument{

			@Override
			public void play() {
				// TODO Auto-generated method stub
				System.out.println("Piano is playing toot toot toot toot");
			}
			
		}
	 
	 static class Guitar extends Instrument{

			@Override
			public void play() {
				// TODO Auto-generated method stub
				System.out.println("Piano is playing tin tin tin tin");
			}
			
		}

}
