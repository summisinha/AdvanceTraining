package com.java.problem3;

public class Medicine {
	public void displayLabel()
	{
		System.out.println("Company Name: Globex Pharma");
		System.out.println("Address: Banglore");
	}
 static class Tablet extends Medicine{
	 public  void displayLabel()
		{
			System.out.println("Store is cool dry place");
			
		}
	 
	 static class Syrup extends Medicine{
		 public void displayLabel()
			{
				System.out.println("Consuption is directed by the physician");
				
			}
		 
	 }
	 
	static class Ointement extends Medicine{
		 public void displayLabel()
			{
				System.out.println("for external use only");
				
			}
		 
	 }
 }
}
