package com.java.problem2;

public class StringLength {

		
		public static void main(String args[]) {
			
				String data = "Education";
				if(data.length() >0) {
				//for (int i = 0; i < data.length(); i++) {
				//	data += data[i];
				//}
				System.out.println("The length of the string: " + data.length());
				System.out.println("The string into uppercase: " + data.toUpperCase());
				if (isPalindrome(data)) {
					System.out.println(data + " is a palindrome");
				} else {
					System.out.println(data + " is not a palindrome");
				}
			} else {
				System.out.println("Invalid input");
			}
		}


		static boolean isPalindrome(String word) {
			StringBuilder sb= new StringBuilder(word);
			sb.reverse();
			String rev= sb.toString();
			if(word.equals(rev)) {
				return true;
			}else {
				return false;
			}
			
			//int index = 0;
			//int length = word.length() - 1;
			//while (length > index) {
				//if (word.charAt(index) != word.charAt(length)) {
				//	return false;
				//}
				//index++;
				//length--;
			//}
			//return true;
		}
	}

