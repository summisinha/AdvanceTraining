package com.java.problem1;

public class FindArea {
	
	 public static void main(String[] args)
	   {
	      Rectangle r1 = new Rectangle(); 
	      Rectangle r2 = new Rectangle(60); 
	      Rectangle r3 = new Rectangle(40, 20);
	      Rectangle r4= new Rectangle(8,9);
	      Rectangle r5= new Rectangle(4,9);
	      System.out.println("First rectangle : " + r1.getArea()); 
	      System.out.println("Second rectangle : " + r2.getArea()); 
	      System.out.println("Third Rectangle : " + r3.getArea());
	      System.out.println("Fourth Rectangle : " + r4.getArea());
	      System.out.println("Fifth Rectangle : " + r5.getArea());
	   }

}
