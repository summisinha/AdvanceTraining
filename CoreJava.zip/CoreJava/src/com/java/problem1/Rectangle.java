package com.java.problem1;

public class Rectangle {
	  int length, breadth;
	   // rectangle constructor java
	   Rectangle(int l, int b) 
	   { 
	      length = l; 
	      breadth = b; 
	   } 
	   Rectangle(int l) 
	   { 
	      length = l; 
	      breadth = 20; 
	   } 
	   Rectangle() 
	   { 
	      length = 6; 
	      breadth = 2; 
	   } 
	
	   float getArea() 
	   { 
	      return(length * breadth); 
	   }
	}

