package com.java.problem1;

public class Book
{
    String book_title;
    double book_price;
	
    Book(String title,double price){
    	book_title=title;
    	book_price=price;
    }
	 String getBook_title() {
		return book_title;
	}
	 void setBook_title(String s) {
		this.book_title = s;
	}
	 double getBook_price() {
		return book_price;
	}
	 void setBook_price(double p) {
		this.book_price = p;
	}
   

}
   
  



