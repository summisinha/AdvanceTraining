package com.java.problem1;
import java.util.Scanner;

public class DisplayBook {

	
	static Scanner sc= new Scanner(System.in);
	public static void createBooks(Book[] b) {
		for(int i=0;i<b.length;i++) {
			System.out.println("Enter Book"+(i+1)+"details:");
			System.out.println("Title: ");
			sc.nextLine();
			String t=sc.nextLine();
			System.out.println("Price: ");
			double p=sc.nextDouble();
			b[i]= new Book(t, p);
		}
		
	}
	        
	public static void showBooks(Book[] b) {
		System.out.println("Book Title\t\tPrice");
		System.out.println("---------------------------------------");
		String r="RS";
		for(int i=0;i<b.length;i++) {
			System.out.printf("%-20s%6s",b[i].getBook_title(),r);
			System.out.println(b[i].getBook_price());
		}
		
	}

	public static void main(String[] args) {
		System.out.println("Number of Books: ");
		int n=sc.nextInt();
		Book[] b= new Book[n];
		createBooks(b);
		showBooks(b);
		}
	}

