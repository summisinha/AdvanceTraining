package com.java.problem6;

public class Contact {

	private String fullName;
	private String phoneNumber;
	private String emailId;
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Contact(String fullName, String phoneNumber, String emailId) {
		super();
		this.fullName = fullName;
		this.phoneNumber = phoneNumber;
		this.emailId = emailId;
	}

	
}

