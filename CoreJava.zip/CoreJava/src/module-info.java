module coreJava {
}